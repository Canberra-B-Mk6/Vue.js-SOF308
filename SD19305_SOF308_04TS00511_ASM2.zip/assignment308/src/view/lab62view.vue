<script setup>
import lab6_2 from '../components/lab6_2.vue';
</script>
<template>
    <lab6_2 />
</template>