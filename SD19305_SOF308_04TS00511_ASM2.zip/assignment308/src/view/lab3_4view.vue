<script setup>
import lab3_4 from '../components/lab3_4.vue';
</script>
<template>
    <lab3_4 />
</template>