<script setup>
import lab3_3 from '../components/lab3_3.vue';
</script>
<template>
    <lab3_3 />
</template>