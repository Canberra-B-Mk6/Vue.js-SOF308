<script setup>
import postCreatorPrototype from '../components/postCreatorPrototype.vue';
import { reactive } from "vue";
</script>
<template>
    <postCreatorPrototype/>
    <post-creator :posts="posts" />
</template>

    
