<script setup>
import Profile from '../components/personalProfile.vue';
</script>
<template>
    <Profile />
</template>