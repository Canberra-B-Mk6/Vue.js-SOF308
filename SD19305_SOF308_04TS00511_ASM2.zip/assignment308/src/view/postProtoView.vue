<script setup>
import postComponentPrototype from '../components/postComponentPrototype.vue';

</script>
<template>
    <postComponentPrototype/>
    <post :posts="posts" />
</template>

