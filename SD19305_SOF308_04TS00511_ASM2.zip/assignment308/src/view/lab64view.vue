<script setup>
import lab6_4 from '../components/lab6_4.vue';
</script>
<template>
    <lab6_4 />
</template>