<script setup>
import Register from '../components/register.vue';
</script>
<template>
    <Register/>
</template>