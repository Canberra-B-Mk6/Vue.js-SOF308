<script setup>
import lab6_3 from '../components/lab6_3.vue';
</script>
<template>
    <lab6_3 />
</template>