<script setup>
import Post from '../components/post.vue';
</script>
<template>
    <Post />
</template>