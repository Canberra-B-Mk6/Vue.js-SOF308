<script setup>
import hello from '../components/hello.vue';
</script>
<template>
    <hello/>
</template>