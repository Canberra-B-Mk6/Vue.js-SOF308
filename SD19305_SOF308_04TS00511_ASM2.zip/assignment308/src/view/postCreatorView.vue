<script setup>
import postCreator from '../components/postCreator.vue';
</script>
<template>
    <postCreator />
</template>
