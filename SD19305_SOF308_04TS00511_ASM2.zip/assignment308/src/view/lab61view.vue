<script setup>
import lab6_1 from '../components/lab6_1.vue';
</script>
<template>
    <lab6_1 />
</template>