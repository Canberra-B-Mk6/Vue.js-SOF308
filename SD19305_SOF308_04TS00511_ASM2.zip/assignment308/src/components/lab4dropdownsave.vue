<template>
    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-info-emphasis" href="" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-file"></i> LAB 4
                        </a>
                        <ul class="dropdown-menu">
                          <li><router-link class="dropdown-item" to="/lab4_2view">LAB 4.2</router-link></li>
                          <li><router-link class="dropdown-item" to="/lab3_3view">LAB 4.3</router-link></li>
                          <li><router-link class="dropdown-item" to="/lab3_4view">LAB 4.4</router-link></li>
                      </ul>
                    </li>
</template>