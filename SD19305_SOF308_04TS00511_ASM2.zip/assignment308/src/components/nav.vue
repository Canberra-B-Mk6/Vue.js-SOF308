<template>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <nav class="sticky-top navbar navbar-expand-sm navbar-dark bg-info-subtle">
      <div class="container"> 
          <a class="navbar-brand" href="#">
              <img :src="'logo-energy-pilates.png'" alt="" style="width: 200px;">
              &nbsp;
              <img :src="'skyteam-1-logo-png-transparent.png'" alt="" style="width: 40px;">
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
              <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="collapsibleNavbar">
              <ul class="navbar-nav me-auto">
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-info-emphasis" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-list-ul"></i> Posts
                    </a>
                    <ul class="dropdown-menu">
                        <li><router-link class="dropdown-item" to="/postView">All posts</router-link></li>
                        <li><router-link class="dropdown-item" to="/postCreator">Posts</router-link></li>
                    </ul>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link text-info-emphasis" href="#"><i class="bi bi-film"></i> Videos</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link text-info-emphasis" href="#"><i class="bi bi-info-circle"></i> Introductions</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link text-info-emphasis" href="#"><i class="bi bi-calendar2-event"></i> Events</a>
                  </li>
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle text-info-emphasis" href="#" role="button" data-bs-toggle="dropdown">
                          <i class="bi bi-person-badge"></i> Account
                      </a>
                      <ul class="dropdown-menu">
                          <li><router-link class="dropdown-item" to="/profile">Profile</router-link></li>
                          <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#logRegForm">Login</a></li>
                          <li><a class="dropdown-item" href="#">Forgot Password?</a></li>
                          <li><router-link class="dropdown-item" to="/register">Membership signup</router-link></li>
                      </ul>
                  </li>
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle text-info-emphasis" href="#" role="button" data-bs-toggle="dropdown">
                          <i class="bi bi-file-code"></i> LAB 4
                      </a>
                      <ul class="dropdown-menu">
                        <li><router-link class="dropdown-item" to="/lab4_2view">LAB 4.2</router-link></li>
                        <li><router-link class="dropdown-item" to="/lab3_3view">LAB 4.3</router-link></li>
                        <li><router-link class="dropdown-item" to="/lab3_4view">LAB 4.4</router-link></li>
                    </ul>
                  </li>
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle text-info-emphasis" href="#" role="button" data-bs-toggle="dropdown">
                          <i class="bi bi-file-code"></i> LAB 6
                      </a>
                      <ul class="dropdown-menu">
                        <li><router-link class="dropdown-item" to="/lab6_1view">LAB 6.1</router-link></li>
                        <li><router-link class="dropdown-item" to="/lab6_2view">LAB 6.2</router-link></li>
                        <li><router-link class="dropdown-item" to="/lab6_3view">LAB 6.3</router-link></li>
                        <li><router-link class="dropdown-item" to="/lab6_4view">LAB 6.4</router-link></li>
                    </ul>
                  </li>
              </ul>
              <ul class="navbar-nav d-flex ms-auto">
                  <li class="nav-item">
                      <a class="nav-link text-info-emphasis">Tiếng Việt</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link text-info-emphasis">English</a>
                  </li>
              </ul>
          </div>
      </div>
  </nav>
  <div class="container">
  <div v-if="welcome" class="p-5 col-sm-5 items-center">
  <h3>Welcome, {{ propUsername }}!</h3>
  </div>
  </div>

  <!-- Modal for Login/Register -->
  <div class="modal" id="logRegForm">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Login</h4>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <form @submit.prevent="login">
      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" v-model="email" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" v-model="password" required>
      </div>
      <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Login</button>
          
    </form>
        </div>
      </div> 
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { getCookie, setCookie } from '../utils/cookies.js';

const email = ref('');
const password = ref('');
const emailError = ref('');
const passwordError = ref('');
const welcome = ref('');

const propLogEmail = 'asm308@duc.com';
const propLogPass = 'asm308';
const propUsername = ref('Truong Anh Duc');

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

onMounted(() => {
  // getsaved user data from cookies on mount
  const savedEmail = getCookie('user_email');
  const savedFullname = getCookie('user_fullname');
  
  if (savedEmail) {
    email.value = savedEmail;  // autofill email
  }
  
  if (savedFullname) {
    propUsername.value = savedFullname;  // get and use stored name
  }
});

const login = () => {
  emailError.value = '';
  passwordError.value = '';

  if (!email.value) {
    emailError.value = 'Email là bắt buộc.';
  } else if (!emailRegex.test(email.value)) {
    emailError.value = 'Vui lòng nhập email hợp lệ.';
  }

  if (!password.value) {
    passwordError.value = 'Mật khẩu là bắt buộc.';
  }

  if (!emailError.value && !passwordError.value) {
    if (email.value === propLogEmail && password.value === propLogPass) {
      setCookie("username", propUsername.value, 1);  // name cookie rot after 1 days
      setCookie("user_email", email.value, 1);  // email cookie rot after 1 days
      welcome.value = `Welcome, ${propUsername.value}!`;
    } else {
      emailError.value = 'Thông tin đăng nhập không chính xác.';
    }
  }
};
</script>
