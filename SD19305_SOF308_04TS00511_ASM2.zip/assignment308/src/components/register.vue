<template>
<h2>Đăng Ký</h2>
<form @submit.prevent="handleRegister">
<div class="row">
<div class="col-8">
<div class="mb-3">
<label for="fullname" class="form-label">Họ và Tên</label>
<input type="text" class="form-control" id="fullname" placeholder="Nhập họ và tên" v-model="form.fullname" required>
<div class="invalid-feedback">
 Vui lòng nhập họ và tên.
</div>
                                  </div>
                                  <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" placeholder="Nhập email" v-model="form.email" required>
                                    <div class="invalid-feedback">
                                      Vui lòng nhập một địa chỉ email hợp lệ.
                                    </div>
                                  </div>
                                  <div class="mb-3">
                                    <label for="phone" class="form-label">Số Điện Thoại</label>
                                    <input type="tel" class="form-control" id="phone" placeholder="Nhập số điện thoại" v-model="form.phone" required>
                                    <div class="invalid-feedback">
                                      Vui lòng nhập số điện thoại.
                                    </div>
                                  </div>
                                  <div class="mb-3">
                                    <label for="password" class="form-label">Mật Khẩu</label>
                                    <input type="password" class="form-control" id="password" placeholder="Nhập mật khẩu" v-model="form.password" required minlength="8">
                                    <div class="invalid-feedback">
                                      Mật khẩu phải có ít nhất 8 ký tự.
                                    </div>
                                  </div>
                                  <div class="mb-3">
                                    <label for="confirm-password" class="form-label">Xác Nhận Mật Khẩu</label>
                                    <input type="password" class="form-control" id="confirm-password" placeholder="Xác nhận mật khẩu" v-model="form.confirmPassword" required>
                                    <div id="password-error" class="invalid-feedback">
                                      Mật khẩu không khớp.
                                    </div>
                                  </div>
                                  <div class="mb-3">
                                    <label>Giới Tính</label>
                                    <div class="form-check">
                                      <input class="form-check-input" type="radio" name="gender" id="male" value="male" v-model="form.gender" checked required>
                                      <label class="form-check-label" for="male">
                                        Nam
                                      </label>
                                    </div>
                                    <div class="form-check">
                                      <input class="form-check-input" type="radio" name="gender" id="female" value="female" v-model="form.gender" required>
                                      <label class="form-check-label" for="female">
                                        Nữ
                                      </label>
                                    </div>
                                    <div class="form-check">
                                      <input class="form-check-input" type="radio" name="gender" id="other" value="other" v-model="form.gender" required>
                                      <label class="form-check-label" for="other">
                                        Others
                                      </label>
                                    </div>
                                    <div class="invalid-feedback">
                                      Vui lòng chọn giới tính.
                                    </div>
                                  </div>
                                  <div class="mb-3">
                                    <label for="language" class="form-label">Ngôn Ngữ</label>
                                    <select class="form-select" id="language" v-model="form.language" required>
                                      <option value="vi">Tiếng Việt</option>
                                      <option value="en">English</option>
                                    </select>
                                    <div class="invalid-feedback">
                                      Vui lòng chọn ngôn ngữ.
                                    </div>
                                  </div>
                                  <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" v-model="form.terms" required>
                                    <label class="form-check-label" for="terms"> 
                                      Tôi đồng ý với các điều khoản và điều kiện
                                    </label>
                                    <div class="invalid-feedback">
                                      Bạn phải đồng ý với các điều khoản và điều kiện.
                                    </div>
                                  </div>
                                  <router-link to="/postView"><button type="submit" class="btn btn-primary">Đăng Ký</button></router-link> 
                                </div>
                              <div class="col-4">
                                <div class="mt-4">
                                    <h3>Thông Tin Đăng Ký:</h3>
                                    <ul>
                                      <li><strong>Họ và Tên:</strong> {{ form.fullname }}</li>
                                      <li><strong>Email:</strong> {{ form.email }}</li>
                                      <li><strong>Số Điện Thoại:</strong> {{ form.phone }}</li>
                                      <li><strong>Giới Tính:</strong> {{ form.gender }}</li>
                                      <li><strong>Ngôn Ngữ:</strong> {{ form.language === 'vi' ? 'Tiếng Việt' : 'English' }}</li>
                                    </ul>
                                </div>
                              </div> 
                              </div> 
                            </form>
</template>

<script setup>
import { ref } from 'vue';
import { getCookie, setCookie } from '../utils/cookies.js';
const isRegistered = ref(false);
const form = ref({
  fullname: '',
  email: '',
  phone: '',
  password: '',
  confirmPassword: '',
  gender: 'male',
  language: 'vi',
  terms: false
});

const handleRegister = () => {
  if (form.value.password !== form.value.confirmPassword) {
    alert('Mật khẩu không khớp!');
    return;
  }

  // Store user data in cookies
  setCookie('user_fullname', form.value.fullname, 3);  // Store for 3 days
  setCookie('user_email', form.value.email, 3);

  // Set registration as successful
  isRegistered.value = true;

  // Optional: Reset form after successful registration
  form.value = {};
};
</script>


