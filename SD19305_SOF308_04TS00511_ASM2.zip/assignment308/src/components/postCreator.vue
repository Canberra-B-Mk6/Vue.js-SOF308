<template>
<div class="container">
<div class="row">
    <div class="col-sm-8">
      <h2 class="text-info mb-3">Post creator</h2>
      <div class="card blog bg-info-subtle">
        <div class="card-body bg-info-subtle">
          <!--post content form-->
          <form @submit.prevent="createPost">
            <div class="mb-3">
              <label for="postTitle" class="form-label">Title</label>
              <input v-model="newPost.title" type="text" class="form-control" id="postTitle" placeholder="Post title here" />
            </div>
            <div class="mb-3">
              <label for="postContent" class="form-label">Content</label>
              <textarea v-model="newPost.content" id="content" name="content" class="form-control"></textarea>
            </div>
            <div class="mb-3">
              <label for="language" class="form-label">Language</label>
              <select v-model="newPost.language" class="form-select" id="language">
                <option value="vi">Tiếng Việt</option>
                <option value="en">English</option>
              </select>
            </div>
            <div class="mb-3">
        <label for="postImage" class="form-label">Upload Image</label>
        <input type="file" class="form-control" id="postImage" @change="handleImageUpload" />
      </div>
      <!-- Display the chosen image -->
      <div v-if="previewImage">
        <h4>Selected Image Preview:</h4>
        <img :src="previewImage" alt="Preview" class="img-thumbnail" />
      </div>
            <div class="mb-3 form-check">
              <input type="checkbox" class="form-check-input" id="terms" v-model="newPost.agreement" />
              <label class="form-check-label" for="terms">
                <strong>I agree that none of these informations are true or factual.</strong>
              </label>
            </div>
            <button type="submit" class="btn btn-primary">POST</button>
          </form>
        </div>
      </div>
      <post :posts="posts" @delete-post="deletePost"/>
    </div>
         <div class="col-sm-4">
            <h3 class="text-info mt-2">Featured</h3>
             <ul class="list-group">
                 <li class="list-group-item active d-flex justify-content-between align-content-center">
                     <a class="nav-link" href="#">Fleet</a>
                     <span class="badge bg-primary rounded-pill">9</span>
                 </li>
                 <li class="list-group-item bg-info d-flex justify-content-between align-content-center">
                     <a class="nav-link" href="#">News</a>
                     <span class="badge bg-primary rounded-pill">11</span>
                 </li>
                 <li class="list-group-item bg-info d-flex justify-content-between align-content-center">
                     <a class="nav-link" href="#">Videos</a>
                     <span class="badge bg-primary rounded-pill">2001</span>
                 </li>
             </ul>
            <div class="col-sm-12 bg-light-subtle rounded ">
                <div class="card-header text-uppercase text-info-emphasis border-bottom mb-2">
                <h3 class="text-info mt-2">Popular posts</h3>
                </div>
                <div class="row mt-3 mb-3 rounded-2">
                    <div class="col-sm-5 "><img :src="'corevalue.jpg'" class="img-thumbnail"></div>
                    <div class="col-sm-7">Vietnamese airlines continue to be plagued by pilot shortage <i class="bi bi-chat-square-fill"></i> 13</div>
                </div>
                <div class="row mb-3 rounded-2">
                    <div class="col-sm-5"><img :src="'orange_300x300.jpg'" class="img-thumbnail"></div>
                    <div class="col-sm-7">Vietnam Airlines new Boeing 787-9 register: VN-A878 arrived from Boeing Field<br><i class="bi bi-check-circle-fill"></i> 79</div>
                </div>
                <div class="row mb-3 rounded-2">
                    <div class="col-sm-5"><img :src="'sesameoil_300x300.jpg'" class="img-thumbnail"></div>
                    <div class="col-sm-7">With President Joe Biden as ‘guarantor’, Vietnam Airlines orders 50 Boeing 737 MAX 8 <br><i class="bi bi-chat-square-fill"></i> 50</div>
                </div>
            </div>
        </div>
</div>
</div>
</template>

<script>
import { reactive, ref, onMounted } from "vue";
import post from "./postComponentPrototype.vue";

export default {
  components: {
    post,
  },
  setup() {
    const posts = reactive([]);

    // Reactive object for new post
    const newPost = ref({
      language: "",
      title: "",
      content: "",
      image: null, // Store the image URL
    });

    // Reactive variable for preview image
    const previewImage = ref(null);

    // Load posts from local storage
    const loadPosts = () => {
      const savedPosts = localStorage.getItem("posts");
      if (savedPosts) {
        posts.push(...JSON.parse(savedPosts));
      }
    };

    // Save posts to local storage
    const savePosts = () => {
      localStorage.setItem("posts", JSON.stringify(posts));
    };

    const deletePost = (index) => {
      posts.splice(index, 1); // Remove the post from the array
      savePosts(); // Update local storage
    };

    // Handle image upload
    const handleImageUpload = (event) => {
      const file = event.target.files[0];
      if (file) {
        previewImage.value = URL.createObjectURL(file); // Generate a preview URL
        newPost.value.image = previewImage.value; // Store it in the post
      }
    };

    // Create a new post
    const createPost = () => {
      if (newPost.value.title && newPost.value.content) {
        // Push a new post object to the posts array
        posts.push({ ...newPost.value });

        // Save to local storage
        savePosts();

        // Reset the form
        newPost.value = { title: "", content: "", image: null, language: "" };
        previewImage.value = null;
      } else {
        alert("Please fill out all fields, genius.");
      }
    };

    // Load posts when the component is mounted
    onMounted(loadPosts);

    return { newPost, posts, previewImage, handleImageUpload, createPost,  deletePost };
  },
};

</script>
  