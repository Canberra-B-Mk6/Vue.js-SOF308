<template>
  <div>
    <h3>All Posts</h3>
    <div v-for="(post, index) in posts" :key="index" class="card mb-3">
      <div class="card-header bg-info-subtle">
        <strong>{{ post.title }} ({{ post.language }})</strong>
        <button class="btn btn-danger btn-sm align-right" @click="emitDeletePost(index)">
          Delete
        </button>
      </div>
      <div class="card-body">
        <div v-if="post.image">
          <img :src="post.image" alt="Uploaded" class="img-thumbnail" />
        </div>
        <p>{{ post.content }}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    posts: {
      type: Array,
      required: true,
    },
  },
  methods: {
    emitDeletePost(index) {
      this.$emit("delete-post", index); // Emit an event with the index of the post to delete
    },
  },
};
</script>

  