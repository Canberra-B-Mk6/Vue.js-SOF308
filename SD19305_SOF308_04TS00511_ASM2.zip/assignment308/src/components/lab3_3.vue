<template>
    <div>
      <h1>{{ greeting }}</h1>
      <button v-bind:title="buttonTitle" @click="changeGreeting">Click to change greetings</button>
    </div>
</template>
  
  <script>
  export default {
    data() {
      return {
        greetings: ['Xin chào!', 'Привет!', 'Hello!', 'Bonjour!'],
        currentGreeting: 0,
        buttonTitle: 'Click to change greetings',
      };
    },
    computed: {
      greeting() {
        return this.greetings[this.currentGreeting];
      },
    },
    methods: {
      changeGreeting() {
        this.currentGreeting = (this.currentGreeting + 1) % 4;
        this.buttonTitle = 'Greetings changed!';
      },
    },
  };
  </script>
  