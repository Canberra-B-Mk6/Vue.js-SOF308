<template>
    <div class="row">
      <div class="col-sm-8">
        <h2 class="text-info mb-3">Post creator</h2>
        <div class="card blog bg-info-subtle">
          <div class="card-body bg-info-subtle">
            <form @submit.prevent="createPost">
              <div class="mb-3">
                <label for="postTitle" class="form-label">Title</label>
                <input v-model="newPost.title" type="text" class="form-control" id="postTitle" placeholder="Post title here" />
              </div>
              <div class="mb-3">
                <label for="postContent" class="form-label">Content</label>
                <textarea v-model="newPost.content" id="content" name="content" class="form-control"></textarea>
              </div>
              <div class="mb-3">
                <label for="language" class="form-label">Language</label>
                <select v-model="newPost.language" class="form-select" id="language">
                  <option value="vi">Tiếng Việt</option>
                  <option value="en">English</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="postImage" class="form-label">Upload image</label>
                <input type="file" class="form-control" id="postImage" @change="handleImageUpload" />
              </div>
              <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="terms" v-model="newPost.agreement" />
                <label class="form-check-label" for="terms">
                  I agree that all information is factual.
                </label>
              </div>
              <button type="submit" class="btn btn-primary">POST</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { ref } from "vue";
  
  export default {
    props: {
      posts: {
        type: Array,
        required: true,
      },
    },
    setup(props) {
      const newPost = ref({
        title: "",
        content: "",
        language: "en",
        image: null,
        agreement: false,
      });
  
      const handleImageUpload = (event) => {
        newPost.value.image = event.target.files[0];
      };
  
      const createPost = () => {
        if (newPost.value.agreement) {
          props.posts.push({ ...newPost.value, id: Date.now() });
          newPost.value = {
            title: "",
            content: "",
            language: "en",
            image: null,
            agreement: false,
          };
        } else {
          alert("Please agree to the terms before posting.");
        }
      };
  
      return { newPost, createPost, handleImageUpload };
    },
  };
  </script>
  