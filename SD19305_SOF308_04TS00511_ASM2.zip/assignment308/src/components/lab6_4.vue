<template>
    <div class="container">
      <br>
    <div class="row mt-2">
      <div class="col-sm-4 mt-3 text-info-emphasis">
      <h2>Quản lý học sinh</h2>
      <!-- Form thêm/sửa học sinh -->
      <form @submit.prevent="handleSubmit">
        <input v-model="student.name" type="text" placeholder="Họ và tên" class="mb-3 rounded-2 form-control" required /><br>
        <input v-model.number="student.score" type="number" placeholder="Điểm" class="mb-3 rounded-2 form-control" required /><br>
        <input v-model="student.dob" type="date" class="mb-3 rounded-2 form-control" required /><br>
        <button type="submit" class="btn btn-primary">
          {{ isEditing ? 'Cập nhật' : 'Thêm' }}
        </button>
      </form>
    </div>
    <div class="col-sm-8 text-info-emphasis">
      <!-- Danh sách học sinh -->
      <table class="table mt-4">
        <thead class="bg-info-subtle">
          <tr class="bg-info-subtle">
            <th>Họ tên</th>
            <th>Điểm</th>
            <th>Ngày sinh</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(student, index) in students" :key="index" class="bg-info-subtle text-info-emphasis">
            <td>{{ student.name }}</td>
            <td>{{ student.score }}</td>
            <td>{{ student.dob }}</td>
            <td>
              <button class="btn btn-warning btn-sm col-3" @click="editStudent(index)">Sửa</button> &nbsp;
              <button class="btn btn-danger btn-sm col-3" @click="deleteStudent(index)">Xóa</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        students: [], // Danh sách học sinh
        student: {
          name: '',
          score: '',
          dob: '',
        },
        isEditing: false, // Đang trong chế độ chỉnh sửa hay không
        editIndex: null, // Vị trí học sinh đang chỉnh sửa
      };
    },
    methods: {
      handleSubmit() {
        if (this.isEditing) {
          // Cập nhật thông tin học sinh
          this.$set(this.students, this.editIndex, { ...this.student });
          this.isEditing = false;
        } else {
          // Thêm học sinh mới
          this.students.push({ ...this.student });
        }
        this.resetForm();
      },
      editStudent(index) {
        // Bắt đầu chỉnh sửa học sinh
        this.student = { ...this.students[index] };
        this.isEditing = true;
        this.editIndex = index;
      },
      deleteStudent(index) {
        // Xóa học sinh
        this.students.splice(index, 1);
      },
      resetForm() {
        this.student = { name: '', score: '', dob: '' };
        this.isEditing = false;
        this.editIndex = null;
      },
    },
  };
  </script>
  