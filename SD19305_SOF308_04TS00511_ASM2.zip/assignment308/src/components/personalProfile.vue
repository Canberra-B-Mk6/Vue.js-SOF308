<template>
  <div class="container">
    <div class="row">
      <!-- About Me Card -->
      <div class="col-sm-4">
        <h2 class="text-info mb-3">About me</h2>
        <div class="card blog bg-info-subtle">
          <br>
          <img :src="profile.picture || 'Screenshot 2024-10-31 164825.png'" class="card-img-top rounded-circle px-4" alt="Profile Picture" />
          <div class="card-body bg-info-subtle">
            <br>
            <h5 class="card-title">Introductions</h5>
            <p class="card-text">{{ profile.intro }}</p>
            <p class="card-text">Quote: "{{ profile.quote }}"</p>
            <p class="card-text">Fullname: {{ profile.fullname }}</p>
            <p class="card-text">Email: {{ profile.email }}</p>
            <p class="card-text">Mobile: {{ profile.mobile }}</p>
          </div>
        </div>
      </div>

      <!-- Personal Details Form -->
      <div class="col-sm-8">
        <h2 class="text-info mb-3">Profile</h2>
        <div class="card blog bg-info-subtle">
          <div class="card-body bg-info-subtle">
            <form @submit.prevent="updateProfile">
              <div class="mb-3">
                <label for="fullname" class="form-label">Fullname</label>
                <input type="text" class="form-control" id="fullname" v-model="tempProfile.fullname" placeholder="Your Name" />
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" v-model="tempProfile.email" placeholder="Your Email" />
              </div>
              <div class="mb-3">
                <label for="phone" class="form-label">Mobile</label>
                <input type="tel" class="form-control" id="phone" v-model="tempProfile.mobile" placeholder="Your Mobile Number" />
              </div>
              <div class="mb-3">
                <label for="quote" class="form-label">Quote</label>
                <input type="text" class="form-control" id="quote" v-model="tempProfile.quote" placeholder="Your Quote" />
              </div>
              <div class="mb-3">
                <label for="intro" class="form-label">Introductions</label>
                <input type="text" class="form-control" id="intro" v-model="tempProfile.intro" placeholder="Short Introduction" />
              </div>
              <div class="mb-3">
                <label for="picture" class="form-label">Profile Picture</label>
                <input type="file" class="form-control" id="picture" @change="onPictureSelected" />
              </div>
              <button type="submit" class="btn btn-primary">Update</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script>
import { reactive, onMounted } from "vue";
import { setCookie, getCookie } from '../utils/cookies.js';

export default {
  setup() {
    const profile = reactive({
      fullname: "Truong Anh Duc",
      email: "ductats00511@fpt.edu.vn",
      mobile: "09********",
      quote: "Si vis pacem, para bellum",
      intro: "Aviation enthusiast and more.",
      picture: " ", // Profile picture
    });

    const tempProfile = reactive({ ...profile });

    const onPictureSelected = (event) => {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          console.log("Picture selected: ", reader.result); // Debug log
          tempProfile.picture = reader.result; // Save base64 image to tempProfile
        };
        reader.readAsDataURL(file);
      } else {
        console.error("No file selected.");
      }
    };


    const updateProfile = () => {
  Object.assign(profile, tempProfile);

  // Save to localStorage
  localStorage.setItem("user_profile", JSON.stringify(profile));
  console.log("Profile saved to localStorage:", profile);
};

onMounted(() => {
  const savedProfile = localStorage.getItem("user_profile");
  if (savedProfile) {
    console.log("Loaded profile from localStorage:", savedProfile); // Debug log
    Object.assign(profile, JSON.parse(savedProfile));
    Object.assign(tempProfile, JSON.parse(savedProfile));
  }
});

    return {
      profile,
      tempProfile,
      updateProfile,
      onPictureSelected,
    };
  },
};
</script>

