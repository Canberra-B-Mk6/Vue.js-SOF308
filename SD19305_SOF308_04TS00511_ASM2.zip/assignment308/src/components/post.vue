<template>
    <div class="row">
        <div class="col-sm-4">
            <h3 class="text-info mt-2">Featured</h3>
             <ul class="list-group">
                 <li class="list-group-item active d-flex justify-content-between align-content-center">
                     <a class="nav-link" href="#">Fleet</a>
                     <span class="badge bg-primary rounded-pill">9</span>
                 </li>
                 <li class="list-group-item bg-info d-flex justify-content-between align-content-center">
                     <a class="nav-link" href="#">News</a>
                     <span class="badge bg-primary rounded-pill">11</span>
                 </li>
                 <li class="list-group-item bg-info d-flex justify-content-between align-content-center">
                     <a class="nav-link" href="#">Videos</a>
                     <span class="badge bg-primary rounded-pill">2001</span>
                 </li>
             </ul>
            <div class="col-sm-12 bg-light-subtle rounded ">
                <div class="card-header text-uppercase text-info-emphasis border-bottom mb-2">
                <h3 class="text-info mt-2">Popular posts</h3>
                </div>
                <router-link to="/postDetail" class="text-decoration-none"><div class="row mt-3 mb-3 rounded-2">
                    <div class="col-sm-5 "><img :src="'corevalue.jpg'" class="img-thumbnail"></div>
                    <div class="col-sm-7">Vietnamese airlines continue to be plagued by pilot shortage <i class="bi bi-chat-square-fill"></i> 13</div>
                </div></router-link>
                <div class="row mb-3 rounded-2">
                    <div class="col-sm-5"><img :src="'orange_300x300.jpg'" class="img-thumbnail"></div>
                    <div class="col-sm-7">Vietnam Airlines new Boeing 787-9 register: VN-A878 arrived from Boeing Field<br><i class="bi bi-check-circle-fill"></i> 79</div>
                </div>
                <div class="row mb-3 rounded-2">
                    <div class="col-sm-5"><img :src="'sesameoil_300x300.jpg'" class="img-thumbnail"></div>
                    <div class="col-sm-7">With President Joe Biden as ‘guarantor’, Vietnam Airlines orders 50 Boeing 737 MAX 8 <br><i class="bi bi-chat-square-fill"></i> 50</div>
                </div>
            </div>
        </div>
        <div class="col-sm-8">
            <h3 class="text-info mt-2">All posts</h3>
            <div class="row">
                <div class="col-sm-6 mb-4">
<router-link to="/postDetail" class="text-decoration-none"><div class="card blog bg-light-subtle align-content-center ">
                        <div class="card-header text-uppercase text-info-emphasis border-bottom mb-2">
                            Phương pháp tập Pilates giúp hồi phục chấn thương cột sống
                            <i class="bi bi-chat-square-fill"></i> 10
                        </div>
                        <img :src="'tap-piltes.jpg'">
                        <div class="card-body text-info-emphasis bg-light-subtle">Vietnam Airlines and Boeing – the American multinational corporation that designs, manufactures, and sells airplanes, rotorcraft, rockets, satellites, and missiles worldwide have signed a memorandum of understanding on the purchase of 50 Boeing 737 MAX narrow-body aircrafts worth USD 10 billion.</div>
                        <br>
                    </div> </router-link>
                </div>
                <div class="col-sm-6 mb-4">
                    <div class="card blog bg-light-subtle align-content-center">
                        <div class="card-header text-uppercase text-info-emphasis border-bottom mb-2">
                            Phương pháp tập Pilates 1 giúp 
                            <i class="bi bi-chat-square-fill"></i> 10
                        </div>
                        <img :src="'tap-pilates1.jpg'">
                        <div class="card-body text-info-emphasis bg-light-subtle">Vietnam Airlines and Boeing – the American multinational corporation that designs, manufactures, and sells airplanes, rotorcraft, rockets, satellites, and missiles worldwide have signed a memorandum of understanding on the purchase of 50 Boeing 737 MAX narrow-body aircrafts worth USD 10 billion.</div>
                        <br>
                    </div> 
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="card blog bg-light-subtle align-content-center">
                        <div class="card-header text-uppercase text-info-emphasis border-bottom mb-2">
                            Heart disease
                            <i class="bi bi-chat-square-fill"></i> 10
                        </div>
                        <img :src="'tim-mach.jpg'">
                        <div class="card-body text-info-emphasis bg-light-subtle">Vietnam Airlines and Boeing – the American multinational corporation that designs, manufactures, and sells airplanes, rotorcraft, rockets, satellites, and missiles worldwide have signed a memorandum of understanding on the purchase of 50 Boeing 737 MAX narrow-body aircrafts worth USD 10 billion.</div>
                        <br>
                    </div> 
                </div>
                <div class="col-sm-6">
                    <div class="card blog bg-light-subtle align-content-center">
                        <div class="card-header text-uppercase text-info-emphasis border-bottom mb-2">
                            Eat clean
                            <i class="bi bi-chat-square-fill"></i> 10
                        </div>
                        <img :src="'eat-clean.png'">
                        <div class="card-body text-info-emphasis bg-light-subtle">Vietnam Airlines and Boeing – the American multinational corporation that designs, manufactures, and sells airplanes, rotorcraft, rockets, satellites, and missiles worldwide have signed a memorandum of understanding on the purchase of 50 Boeing 737 MAX narrow-body aircrafts worth USD 10 billion.</div>
                        <br>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</template>
