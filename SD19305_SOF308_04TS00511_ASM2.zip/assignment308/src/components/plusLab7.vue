<template>
    <form @submit.prevent="default">
        <div class="mb-3">
            <label for="a" class="form-label">A: </label>
            <input type="number" class="form-control" id="email" placeholder="Nhập numero A" v-model="form.a" required>
        </div>
        <div class="mb-3">
            <label for="b" class="form-label">B: </label>
            <input type="number" class="form-control" id="phone" placeholder="Nhập numero B" v-model="form.b" required>
        </div>
        <div class="mb-3">
            <h2>Answer: {{ form.answer }} </h2>
            
        </div>
        <button type="submit" class="btn btn-primary" @click="plus"> + </button>
        <button type="submit" class="btn btn-primary"  @click="deduct"> - </button>
        <button type="submit" class="btn btn-primary"  @click="multiply"> X </button>
        <button type="submit" class="btn btn-primary"  @click="divide"> / </button>
    </form>
</template>
<script setup>
import { reactive } from 'vue';

const form = reactive({
    a: null,
    b: null,
    answer: null,
});

const plus = () => {
    if (form.a !== null && form.b !== null) {
        form.answer = form.a + form.b;
    }
};

const deduct = () => {
    if (form.a !== null && form.b !== null) {
        form.answer = form.a - form.b;
    }
};

const multiply = () => {
    if (form.a !== null && form.b !== null) {
        form.answer = form.a * form.b;
    }
};

const divide = () => {
    if (form.a !== null && form.b !== null) {
        if (form.b !== 0) {
            form.answer = form.a / form.b;
        } else {
            form.answer = "Error: Division by 0!";
        }
    }
};
</script>