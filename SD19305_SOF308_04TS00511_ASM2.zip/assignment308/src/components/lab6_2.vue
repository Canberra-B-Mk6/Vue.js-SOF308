<template>
    <div class="container">
      <h3>Enter your month:</h3>
      <input type="number" v-model.number="month" />
      <p v-if="month < 1 || month > 12" style="color: red">Please enter a month between 1 and 12!</p>
      <p v-else-if="month >= 1 && month <= 3">Spring</p>
      <p v-else-if="month <= 6">Summer</p>
      <p v-else-if="month <= 9">Autumn</p>
      <p v-else>Winter</p>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  
  const month = ref(1);
  </script>
  