<template>
    <div class="container mt-5">
            <h1 class="text-center">Aircrafts around the world</h1>
            <div class="row">
                <div class="col-sm-4">
                    <div class="card">
                    <img :src="items[0].image" alt="Hình ảnh" />
                    <div class="card-body">
                    <h3 class="card-title">{{ items[0].title }}</h3>
                    <p class="card-text">{{ items[0].content }}</p>
                    <button class="btn btn-info">Xem chi tiết </button>
                </div>
            
        </div>
        </div>
        <div class="col-sm-4">
            <div class="card">
                <img :src="items[1].image" alt="Hình ảnh" />
                <div class="card-body">
                    <h3 class="card-title">{{ items[1].title }}</h3>
                    <p class="card-text">{{ items[1].content }}</p>
                    <button class="btn btn-info">Xem chi tiết </button>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card">
                <img :src="items[2].image" alt="Hình ảnh" />
                <div class="card-body">
                    <h3 class="card-title">{{ items[2].title }}</h3>
                    <p class="card-text">{{ items[2].content }}</p>
                    <button class="btn btn-info">Xem chi tiết </button>
                </div>
            </div>
        </div>
    </div>
</div>
</template>

<script setup>
    import img1 from '../assets/05441cc6e4f64f442520f683118f334c2b35fa3d_2_1500x999.jpeg';
    import img2 from '../assets/05441cc6e4f64f442520f683118f334c2b35fa3d_2_1500x999.jpeg';
    import img3 from '../assets/05441cc6e4f64f442520f683118f334c2b35fa3d_2_1500x999.jpeg';
    const items = ([
    { title: 'Tornado IDS SLE (ASSTA3.1)', content: 'One of the latest improvements...', image: img1
    },
    { title: 'Boeing 787 Dreamliner', content: 'One of Boeing modern long-haul airliners...',
    image: img2 },
    { title: 'Airbus A350 XWB', content: 'One of the most advanced long-haul airliners...', image:
    img3 },
    ]);
</script>