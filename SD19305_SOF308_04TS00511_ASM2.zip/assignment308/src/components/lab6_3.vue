<template>
    <div class="container mt-5">
      <h1 class="text-center">Aircrafts Around the World</h1>
      <div class="row">
        <!-- Use v-for to iterate over the items array -->
        <div class="col-sm-4" v-for="(item, index) in items" :key="index">
          <div class="card">
            <img :src="item.image" alt="Hình ảnh" class="card-img-top" />
            <div class="card-body">
              <h3 class="card-title">{{ item.title }}</h3>
              <p class="card-text">{{ item.content }}</p>
              <button class="btn btn-info">Xem chi tiết</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import img1 from '../assets/05441cc6e4f64f442520f683118f334c2b35fa3d_2_1500x999.jpeg';
  import img2 from '../assets/05441cc6e4f64f442520f683118f334c2b35fa3d_2_1500x999.jpeg';
  import img3 from '../assets/05441cc6e4f64f442520f683118f334c2b35fa3d_2_1500x999.jpeg';
  
  const items = [
    {
      title: 'Tornado IDS SLE (ASSTA3.1)',
      content: 'One of the latest improvements...',
      image: img1,
    },
    {
      title: 'Boeing 787 Dreamliner',
      content: 'One of Boeing modern long-haul airliners...',
      image: img2,
    },
    {
      title: 'Airbus A350 XWB',
      content: 'One of the most advanced long-haul airliners...',
      image: img3,
    },
  ];
  </script>
  