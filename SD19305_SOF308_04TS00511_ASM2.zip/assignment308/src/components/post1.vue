<template>
    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-8 mb-4">
                <h3 class="text-info mt-2 text-center">Panavia Tornado IDS SLE - Forever Young</h3>
                <div class="card blog bg-light-subtle align-content-center">
                    <img :src="'05441cc6e4f64f442520f683118f334c2b35fa3d_2_1500x999.jpeg'">
                    <div class="card-body text-info-emphasis bg-light-subtle">
                    The Panavia Tornado is a multi-role combat aircraft that emerged from a collaborative effort among three European nations: the United Kingdom, West Germany, and Italy. To accomplish this, in 1969 a consortium known as Panavia Aircraft GmbH was formed to oversee the Tornado’s development. The Tornado was designed as a variable-sweep wing aircraft, giving it the capability to operate in various roles, including air superiority, ground attack, and electronic warfare. The first prototype Tornado made its maiden flight in 1974, and production began in the late 1970s. The Tornado entered service with the Royal Air Force, German Air Force, and Italian Air Force in the early 1980s, quickly becoming a cornerstone of NATO’s defence strategy during the Cold War.<br>
                    <br>
                     While the Tornado has begun to show its age with all of its operators either having replaced it or are in the process of replacing it, over the years they have received various improvements and modernisations. Luftwaffe Tornadoes would receive several sets of upgrades over their life times, ASSTA1 (Avionics System Software Tornado in Ada) which introduced the AGM-88 HARM, AS.34 Kormoran II, GBU-24 Paveway III, GBU-16 Paveway II, and Litening II targeting pod among other system improvements. This was followed by ASSTA2 which introduced a display system upgrade for the pilot and navigator, a BOW Advanced Radar Warning System by SAAB, and the Taurus KEPD 350 cruise missile. ASSTA3 would introduce the Link 16 data link and GBU-54 LJDAM while the final upgrade in the series, ASSTA3.1, would introduce new coloured displays for the navigator and the BOZ-101 EC which, unlike the old countermeasure pod, featured a new missile approach warning system. Around this time the cockpit of the Tornado would also be adapted for use of night-vision devices.<br>
                    <br>
                    One of the latest improvements to the German Tornado fleet has been the Service Life Enhancement Program (SLE) which was initiated in 2021 and involves a complete rebuild of each airframe, checking the airframe for cracks and replacing high-wear components with new custom manufactured ones so as to extend the service life to 8,000 hours. The front and main landing gear of the Tornado were also reinforced. Additionally, SAAB was contracted by Panavia to provide updates to the Tornado’s BOW Advanced Radar Warning Receiver in order to enhance their processing power and extend their lifetime.<br>   
                    <br>
                    </div>
                    <br>
                    <img :src="'f158e43102d61b5ab73c84353a36f0afdc9d2d1b_2_1500x999.jpeg'">
                    <details >
                        <summary class="text-info-emphasis bg-light-subtle">
                        Armaments</summary>
                        <p><strong>Air-to-air Missiles</strong><br>
                        AIM-9L/I-1 Sidewinder<br>
                        AIM-2000 IRIS-T<br>
                        AIM-120 AMRAAM (via MFRL)</p>
                        <p><strong>Guided Munitions</strong><br>
                        GBU-54 LJDAM<br>
                        GBU-24 Paveway III<br>
                        GBU-16 Paveway II<br>
                        AS.34 Kormoran II<br>
                        AGM-88 HARM<br>
                        ARMIGER (Anti Radiation Missile with Intelligent Guidance &amp; Extended Range)<br>
                        <a href="/t/diehl-bgt-defence-hope-glide-bomb/11155">HOPE glide bomb</a><br>
                        <a href="/t/diehl-bgt-defence-hosbo-glide-bomb/11154">HOSBO glide bomb</a><br>
                        LaGS (Laser Guided Sidewinder)<br>
                        Taurus KEPD 350</p>
                        <p><strong>Dumb Munitions</strong><br>
                        500 lb Mk 82<br>
                        1000 lb Mk 83<br>
                        BL755<br>
                        Mehrzweckwaffe 1 (MW-1)</p>
                        <p><strong>Ammunition</strong><br>
                        27 mm DM83 PELE (no tracer)<br>
                        27 mm DM93 PELE (tracer)</p>
                        <p><strong>Other</strong><br>
                        Rafael LITENING III<br>
                        Tornado Self Protection Jammer (TSPJ)<br>
                        Saab Avitronics BOZ-101 EC<br>
                        New unicolour blue-grey camouflage as used on the Eurofighter</p>
                        <p><strong>Future Considerations</strong><br>
                        Brimstone</p>
                    </details>
                </div> 
            </div>
            <div class="col-sm-4 mb-4 mt-5">
                <div class="card blog align-content-center">
                <div class="card-header text-uppercase text-info-emphasis mb-2">
                    Write your comments here:
                </div>
                <form @submit.prevent="submitComment">
                    <label for="comment" class="form-label">Comment</label>
                    <textarea v-model="newComment" class="form-control" id="comment" placeholder="Type here" required></textarea>
                    <div class="invalid-feedback">
                    Please type something to send.
                    </div>
                    <button type="submit" class="btn btn-info rounded-2 mt-2">Submit</button>
                </form>
                <div class="card-body text-info-emphasis mt-3">
                    <h5>Comments:</h5>
                    <ul id="commentList" class="list">
                    <div class="comment" v-for="(comment, index) in comments" :key="index">
                        <p><strong>{{ comment.name }}: </strong>{{comment.text }} <br><small>{{ comment.date }}</small></p>
                    </div>
                    </ul>
                </div>
                </div> 
            </div>
        </div>
    </div>
</template>
<script setup>
import { ref, onMounted } from 'vue';
import { getCookie, setCookie } from '../utils/cookies.js';

const newComment = ref('');
const comments = ref([]);
const username = getCookie("username") || "Guest";
console.log(username);
// Fetch comments from cookies on mount
onMounted(() => {
  const savedComments = getCookie('comments');
  if (savedComments) {
    comments.value = JSON.parse(savedComments);  // Parse JSON string back into an array
  }
});

const submitComment = () => {
  if (username === "Guest") {
    alert("You must be logged in to submit a comment."); // Display an alert or your preferred method of notification
    return; // Exit the function
  }
   if (newComment.value.trim()) {
    comments.value.push({
      name: username,  // Use the logged-in user’s name
      text: newComment.value,
      date: new Date().toLocaleString()
    });
    newComment.value = "";  // Clear the textarea after submission

    // Save the updated comments in cookies
    setCookie('comments', JSON.stringify(comments.value), 2);  // Store for 7 days
  }
};

</script>