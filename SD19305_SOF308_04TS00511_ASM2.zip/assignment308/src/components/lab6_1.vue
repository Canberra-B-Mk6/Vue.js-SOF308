<template>
    <div>
      <h2>Enter Average Score:</h2>
      <input v-model.number="averageScore" type="number" placeholder="Enter your average score" />
      <p v-if="averageScore === null || averageScore === ''">Enter a score!</p>
      <p v-else-if="averageScore < 5.0">Poor</p>
      <p v-else-if="averageScore < 6.5">Average</p>
      <p v-else-if="averageScore < 8.0">Good</p>
      <p v-else-if="averageScore < 9.0">Very Good</p>
      <p v-else>Excellent</p>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        averageScore: null,
      };
    },
  };
  </script>
  