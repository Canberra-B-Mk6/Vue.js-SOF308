import { createRouter, createWebHistory } from 'vue-router';
import postView from '../view/postView.vue';
import profileView from '../view/profileView.vue';
import lab3_3view from '../view/lab3_3view.vue';
import lab3_4view from '../view/lab3_4view.vue';
import Hello from '../view/lab4_2view.vue'
import postCreatorView from '../view/postCreatorView.vue';
import post1 from '../components/post1.vue';
import creatorProtoView from '../view/creatorProtoView.vue';
import postProtoView from '../view/postProtoView.vue';
import lab61view from '../view/lab61view.vue';
import lab62view from '../view/lab62view.vue';
import lab63view from '../view/lab63view.vue';
import lab64view from '../view/lab64view.vue';
import registerpageView from '../view/registerpageView.vue';
const router = createRouter({
    history:createWebHistory(import.meta.env.BASE_URL),
    routes:[
        {
            path: '/postView',
            name: 'post',
            component: postView,
        },
        {
            path: '/profile',
            name: 'profile',
            component: profileView,
        },
        {
            path: '/lab3_3view',
            name: 'lab3_3view',
            component: lab3_3view,
        },
        {
            path: '/lab3_4view',
            name: 'lab3_4view',
            component: lab3_4view,
        },
        {
            path: '/lab4_2view',
            name: 'lab4_2view',
            component: Hello,
        },
        {
            path: '/postCreator',
            name: 'postCreator',
            component: postCreatorView,
        },
        {
            path: '/postDetail',
            name: 'postDetail',
            component: post1,
        },
        {
            path: '/creatorProto',
            name: 'creatorProto',
            component: creatorProtoView,
        },
        {
            path: '/postProto',
            name: 'postProto',
            component: postProtoView,
        },
        {
            path: '/lab6_1view',
            name: 'lab6_1view',
            component: lab61view,
        },
        {
            path: '/lab6_2view',
            name: 'lab6_2view',
            component: lab62view,
        },
        {
            path: '/lab6_3view',
            name: 'lab6_3view',
            component: lab63view,
        },
        {
            path: '/lab6_4view',
            name: 'lab6_4view',
            component: lab64view,
        },
        {
            path: '/register',
            name: 'register',
            component: registerpageView,
        },

    ]
})
  
export default router ;