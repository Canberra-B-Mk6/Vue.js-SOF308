<template>
  <naviBar @login="handleLogin" />
  <!--plusLab7 /-->
  <div class="container">
    <RouterView :loggedInUser="loggedInUser" />
  </div>  
</template>

<script setup>
import plusLab7 from './components/plusLab7.vue';
import { ref } from 'vue';
import naviBar from './components/nav.vue';
import { RouterView } from 'vue-router';

const loggedInUser = ref('');

const handleLogin = (username) => {
  loggedInUser.value = username;  // Set the username after successful login
};
</script>
